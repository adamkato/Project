const kinalatbtn = document.getElementById("kinalat");
const carSelection = document.getElementById("cars");
kinalatbtn.addEventListener("click", () => {
    carSelection.scrollIntoView({
        behavior:"smooth"
    });
});